# Python File Analysis and Management System

A premium web application for managing files, with personal authentication, direct downloading, and file analysis capabilities. Built with Python (Flask) and dynamic HTML/CSS (Glassmorphism dark theme).

## Features

*   **Secure Authentication**: Personal login to protect your files (`/login`).
*   **File Management**: Upload, list, and delete files with ease. Uploads go into the `uploads` directory.
*   **Direct Link Downloads**: Download your files directly.
*   **File Analysis**: Get detailed insights into file sizes, MIME types, creation dates, and hex headers.
*   **Premium UI**: Stunning, modern, responsive glassmorphism dark theme. Micro-animations included!

## Setup Instructions

1.  Ensure you have Python 3.8+ installed.
2.  Install dependencies:
    ```bash
    pip install -r requirements.txt
    ```
3.  Run the application:
    ```bash
    python app.py
    ```
4.  Access the web interface at `http://localhost:5000`.

## Container / Remote Access

The app now listens on `0.0.0.0` by default, so it can be reached from outside the container if the port is published.

Example:

```bash
pip install -r requirements.txt && python app.py
```

Optional environment variables:

```bash
HOST=0.0.0.0 PORT=5000 FLASK_DEBUG=1 python app.py
```

## Default Credentials

*   **Username**: admin
*   **Password**: password123

## Author
Built enthusiastically for a futuristic web experience.
