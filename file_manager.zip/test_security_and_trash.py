import tempfile
import unittest
from pathlib import Path
from unittest import mock

import app as app_module


class DummyUrlopenResponse:
    def __init__(self, body):
        self.status = 200
        self._body = body

    def read(self):
        return self._body

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb):
        return False


class FileManagerSecurityTests(unittest.TestCase):
    def setUp(self):
        self.tempdir = tempfile.TemporaryDirectory()
        self.base = Path(self.tempdir.name)
        self.uploads = self.base / 'uploads'
        self.notes = self.base / 'notes'
        self.trash = self.base / 'trash'
        self.database = self.base / 'users.db'
        for folder in (self.uploads, self.notes, self.trash):
            folder.mkdir(parents=True, exist_ok=True)

        self.originals = {
            'DATABASE': app_module.DATABASE,
            'UPLOAD_FOLDER': app_module.UPLOAD_FOLDER,
            'NOTES_FOLDER': app_module.NOTES_FOLDER,
            'TRASH_FOLDER': app_module.TRASH_FOLDER,
            'TESTING': app_module.app.config.get('TESTING', False),
            'UPLOAD_FOLDER_CONFIG': app_module.app.config['UPLOAD_FOLDER'],
            'NOTES_FOLDER_CONFIG': app_module.app.config['NOTES_FOLDER'],
            'TRASH_FOLDER_CONFIG': app_module.app.config['TRASH_FOLDER'],
        }

        app_module.DATABASE = str(self.database)
        app_module.UPLOAD_FOLDER = str(self.uploads)
        app_module.NOTES_FOLDER = str(self.notes)
        app_module.TRASH_FOLDER = str(self.trash)
        app_module.app.config['UPLOAD_FOLDER'] = str(self.uploads)
        app_module.app.config['NOTES_FOLDER'] = str(self.notes)
        app_module.app.config['TRASH_FOLDER'] = str(self.trash)
        app_module.app.config['TESTING'] = True

        self._close_cached_db()
        with app_module.app.app_context():
            app_module.init_db()

        self.client = app_module.app.test_client()
        login_response = self.client.post(
            '/login',
            data={'username': 'admin', 'password': 'password123'},
            follow_redirects=False,
        )
        self.assertEqual(login_response.status_code, 302)

    def tearDown(self):
        self._close_cached_db()
        app_module.DATABASE = self.originals['DATABASE']
        app_module.UPLOAD_FOLDER = self.originals['UPLOAD_FOLDER']
        app_module.NOTES_FOLDER = self.originals['NOTES_FOLDER']
        app_module.TRASH_FOLDER = self.originals['TRASH_FOLDER']
        app_module.app.config['UPLOAD_FOLDER'] = self.originals['UPLOAD_FOLDER_CONFIG']
        app_module.app.config['NOTES_FOLDER'] = self.originals['NOTES_FOLDER_CONFIG']
        app_module.app.config['TRASH_FOLDER'] = self.originals['TRASH_FOLDER_CONFIG']
        app_module.app.config['TESTING'] = self.originals['TESTING']
        self.tempdir.cleanup()

    def _close_cached_db(self):
        with app_module.app.app_context():
            db = getattr(app_module.g, '_database', None)
            if db is not None:
                db.close()
                app_module.g._database = None

    def test_share_create_rejects_traversal_and_public_note_share_stays_confined(self):
        (self.notes / 'safe.md').write_text('# safe', encoding='utf-8')
        outside = self.base / 'outside.md'
        outside.write_text('outside secret', encoding='utf-8')

        response = self.client.post('/share/create', json={'type': 'note', 'filename': '../outside.md'})
        self.assertEqual(response.status_code, 400)
        self.assertFalse(response.get_json()['success'])

        valid_response = self.client.post('/share/create', json={'type': 'note', 'filename': 'safe.md'})
        self.assertEqual(valid_response.status_code, 200)
        self.assertTrue(valid_response.get_json()['success'])

        with app_module.app.app_context():
            db = app_module.get_db()
            db.execute(
                'INSERT INTO shares (id, type, target_filename) VALUES (?, ?, ?)',
                ('badshare', 'note', '../outside.md')
            )
            db.commit()

        public_response = self.client.get('/s/n/badshare')
        self.assertEqual(public_response.status_code, 404)
        self.assertNotIn('outside secret', public_response.get_data(as_text=True))

    def test_share_revoke_rejects_non_json_with_json_error(self):
        response = self.client.post('/share/revoke', data='x', content_type='text/plain')
        self.assertEqual(response.status_code, 400)
        self.assertEqual(
            response.get_json(),
            {'success': False, 'message': '请求必须为 JSON'}
        )

    def test_onlyoffice_callback_requires_token_and_existing_target_file(self):
        target = self.uploads / 'report.txt'
        target.write_text('old content', encoding='utf-8')

        forbidden = self.client.post(
            '/callback/report.txt',
            json={'status': 2, 'url': 'https://example.com/file'}
        )
        self.assertEqual(forbidden.status_code, 403)

        with app_module.app.app_context():
            token = app_module.generate_onlyoffice_callback_token('report.txt')
        missing_status = self.client.post(f'/callback/report.txt?token={token}', json={})
        self.assertEqual(missing_status.status_code, 400)

        with app_module.app.app_context():
            new_file_token = app_module.generate_onlyoffice_callback_token('new.txt')
        missing_target = self.client.post(
            f'/callback/new.txt?token={new_file_token}',
            json={'status': 2, 'url': 'https://example.com/file'}
        )
        self.assertEqual(missing_target.status_code, 404)
        self.assertFalse((self.uploads / 'new.txt').exists())

        with mock.patch('socket.getaddrinfo', return_value=[(None, None, None, None, ('93.184.216.34', 0))]):
            with mock.patch('urllib.request.urlopen', return_value=DummyUrlopenResponse(b'updated')):
                success = self.client.post(
                    f'/callback/report.txt?token={token}',
                    json={'status': 2, 'url': 'https://example.com/file'}
                )
        self.assertEqual(success.status_code, 200)
        self.assertEqual(success.get_json(), {'error': 0})
        self.assertEqual(target.read_bytes(), b'updated')

    def test_preview_rejects_non_json_with_json_error(self):
        response = self.client.post('/api/preview', data='x', content_type='text/plain')
        self.assertEqual(response.status_code, 400)
        self.assertEqual(
            response.get_json(),
            {'success': False, 'message': '请求必须为 JSON'}
        )

    def test_markdown_upload_restores_to_uploads_instead_of_notes(self):
        upload = self.uploads / 'readme.md'
        upload.write_text('markdown upload', encoding='utf-8')

        delete_response = self.client.post('/delete/readme.md')
        self.assertEqual(delete_response.status_code, 200)
        self.assertFalse(upload.exists())
        self.assertTrue((self.trash / 'readme.md').exists())

        restore_response = self.client.post('/trash/restore/readme.md')
        self.assertEqual(restore_response.status_code, 200)
        self.assertTrue((self.uploads / 'readme.md').exists())
        self.assertFalse((self.notes / 'readme.md').exists())

        with app_module.app.app_context():
            db = app_module.get_db()
            metadata = db.execute('SELECT * FROM trash_items WHERE trash_name = ?', ('readme.md',)).fetchone()
            self.assertIsNone(metadata)

    def test_legacy_markdown_trash_requires_explicit_restore_type(self):
        legacy = self.trash / 'legacy.md'
        legacy.write_text('legacy', encoding='utf-8')

        ambiguous_restore = self.client.post('/trash/restore/legacy.md')
        self.assertEqual(ambiguous_restore.status_code, 409)
        self.assertEqual(
            ambiguous_restore.get_json(),
            {
                'success': False,
                'message': '旧回收站中的 Markdown 条目缺少来源信息，请选择恢复为文件或笔记'
            }
        )

        explicit_restore = self.client.post('/trash/restore/legacy.md', json={'item_type': 'file'})
        self.assertEqual(explicit_restore.status_code, 200)
        self.assertTrue((self.uploads / 'legacy.md').exists())
        self.assertFalse((self.notes / 'legacy.md').exists())

    def test_batch_delete_removes_share_and_permanent_delete_endpoint_works(self):
        upload = self.uploads / 'batch.txt'
        upload.write_text('payload', encoding='utf-8')

        share_response = self.client.post('/share/create', json={'type': 'file', 'filename': 'batch.txt'})
        self.assertEqual(share_response.status_code, 200)

        delete_response = self.client.post('/api/batch-delete', json={'filenames': ['batch.txt']})
        self.assertEqual(delete_response.status_code, 200)
        self.assertTrue((self.trash / 'batch.txt').exists())

        with app_module.app.app_context():
            db = app_module.get_db()
            share = db.execute(
                'SELECT id FROM shares WHERE type = ? AND target_filename = ?',
                ('file', 'batch.txt')
            ).fetchone()
            metadata = db.execute(
                'SELECT item_type FROM trash_items WHERE trash_name = ?',
                ('batch.txt',)
            ).fetchone()
            self.assertIsNone(share)
            self.assertIsNotNone(metadata)
            self.assertEqual(metadata['item_type'], 'file')

        permanent_delete = self.client.post('/trash/delete/batch.txt')
        self.assertEqual(permanent_delete.status_code, 200)
        self.assertFalse((self.trash / 'batch.txt').exists())

        with app_module.app.app_context():
            db = app_module.get_db()
            metadata = db.execute(
                'SELECT item_type FROM trash_items WHERE trash_name = ?',
                ('batch.txt',)
            ).fetchone()
            self.assertIsNone(metadata)


if __name__ == '__main__':
    unittest.main()
